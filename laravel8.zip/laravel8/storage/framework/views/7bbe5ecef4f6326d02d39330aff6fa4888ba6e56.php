<?php  
$download = $_POST['download'] ?? 'N';
if( $download == "Y" ) { 
$fileName = $searchValText."_".date('d_m_Y').".xls";
 
// Headers for download 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
header("Content-Type: application/vnd.ms-excel"); 
} ?>
<table id="empTable" class="dataTable" border="1">
    <?php if( $download == "Y" ): ?>
    <tr>
        <td style="text-align:center;padding:10px;" colspan="5"><strong><?php echo e($searchValText); ?></strong></td>
    </tr>
    <?php endif; ?>
    <thead>
        <tr>
            <th>Employee Name</th>
            <th>Department</th>
            <th>Date of Birth</th>
            <th>Date of Joining</th>
            <th>Salary(Monthly)</th>
        </tr>
    </thead>
    <tbody>
        <?php if(isset($empList) && count($empList) > 0 ): ?>
            <?php $__currentLoopData = $empList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($val->EMPLOYEE_NAME); ?></td>
                    <td><?php echo e($val->DEPARTMENT_NAME); ?></td>
                    <td><?php echo e($val->DATE_OF_BIRTH); ?></td>
                    <td><?php echo e($val->DATE_OF_JOIN); ?></td>
                    <td style="text-align:right;"><?php echo e($val->SALARY); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </tbody>
</table>
<?php if(isset($empList) && count($empList) > 0 && $download == "N" && $_SERVER['REQUEST_METHOD'] == "POST"): ?>
    <form method="post" action="<?php echo e(route('search')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" class="searchVal" name="searchVal" value="<?php echo e($_POST['searchVal'] ?? ''); ?>" />
        <input type="hidden" class="dept" name="dept" value="<?php echo e($_POST['dept'] ?? ''); ?>" />
        <input type="hidden" name="download" value="Y" />
        <input type="hidden" name="searchValText" value="<?php echo e($_POST['searchValText']); ?>" />
        <button class="btn btn-dark w-100 mt-2">Download as Excel</button>
    </form>
<?php endif; ?><?php /**PATH E:\wamp64\www\laravel8\resources\views/employee_list.blade.php ENDPATH**/ ?>