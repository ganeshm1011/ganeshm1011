<?php  
$download = $_POST['download'] ?? 'N';
if( $download == "Y" ) { 
$fileName = $searchValText."_".date('d_m_Y').".xls";
 
// Headers for download 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
header("Content-Type: application/vnd.ms-excel"); 
} ?>
<table id="empTable" class="dataTable" border="1">
    <thead>
        <tr>
            <th>Department Name</th>
            <th>Average Salary(Monthly)</th>
        </tr>
    </thead>
    <tbody>
        <?php if(isset($empList) && count($empList) > 0 ): ?>
            <?php $__currentLoopData = $empList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($val->department_name); ?></td>
                    <td style="text-align:right;"><?php echo e($val->avg_salary); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </tbody>
</table>
<?php if(isset($empList) && count($empList) > 0 && $download == "N"): ?>
    <form method="post" action="<?php echo e(route('search')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" class="searchVal" name="searchVal" value="<?php echo e($_POST['searchVal'] ?? ''); ?>" />
        <input type="hidden" class="dept" name="dept" value="<?php echo e($_POST['dept'] ?? ''); ?>" />
        <input type="hidden" name="download" value="Y" />
        <input type="hidden" name="searchValText" value="<?php echo e($_POST['searchValText']); ?>" />
        <button class="btn btn-dark w-100 mt-2">Download as Excel</button>
    </form>
<?php endif; ?>
<?php exit; ?><?php /**PATH E:\wamp64\www\laravel8\resources\views/department_list.blade.php ENDPATH**/ ?>