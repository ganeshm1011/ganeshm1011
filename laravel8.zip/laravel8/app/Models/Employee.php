<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Eloquent;
use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $table = 'tbl_employee';
    protected $primaryKey = 'employee_id';
    protected $fillable = ['employee_name','department_id','date_of_birth','date_of_join','salary'];

}
