<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Eloquent;
use App\Models\Employee as EmployeeModel;
use App\Models\Department;
use Illuminate\Support\Facades\Validator;
use DB;

class Employee extends Controller
{
    public function index() {
        $data['empList'] = EmployeeModel::join('tbl_department','tbl_employee.department_id','=','tbl_department.department_id')->get();
        $data['department'] = Department::all();
        $data['searchValText'] = "";
        return view('default',$data);
    }
    public function search(Request $request) {
        $searchVal = $request->input('searchVal');
        $data['searchValText'] = $request->input('searchValText');
        $dept = $request->input('dept');
        $validator = Validator::make($request->all(), [
            "searchVal" => "required|alpha",
            "dept" => "nullable|numeric"
        ]);
        if($validator->fails()) {
            return abort('404');
        }
        $empQuery = DB::table('tbl_employee')->join('tbl_department','tbl_employee.department_id','=','tbl_department.department_id');
        if($searchVal == "BM") $empQuery->whereMonth('tbl_employee.date_of_birth',date('m')); 
        elseif($searchVal == "CE") $empQuery->whereRaw('timestampdiff(YEAR,date_of_join,current_date()) >= 10')->orderBy('date_of_join','asc');
        elseif($searchVal == "HP") $empQuery->orderBy('salary','desc')->take(15);
        elseif($searchVal == "AS") $empQuery->selectRaw('round(sum(tbl_employee.salary)/count(tbl_employee.department_id)) as avg_salary,department_name')->groupby('tbl_employee.department_id')->orderBy('avg_salary','desc');
        elseif($searchVal == "HS") $empQuery->selectRaw('round(sum(tbl_employee.salary)/count(tbl_employee.department_id)) as avg_salary,department_name')->groupby('tbl_employee.department_id')->orderby('avg_salary','desc')->take(1);
        $data['empList'] = $empQuery->get();
        //dd($data);
        if( $searchVal == "AS" || $searchVal == "HS") { 
            return view('department_list',$data);
        }else {
            return view('employee_list',$data);
        }
    }
       
}
