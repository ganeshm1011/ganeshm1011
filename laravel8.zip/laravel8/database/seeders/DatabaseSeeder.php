<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public $timestamps = false;
    public function run()
    {
        $query = DB::table('tbl_department');
        $query->insert([
            'department_name' => 'Accounts'
        ]);
        $query->insert([
            'department_name' => 'Finance'
        ]);
        $query->insert([
            'department_name' => 'Human Resource'
        ]);
        $query->insert([
            'department_name' => 'Information Technology'
        ]);
        $query->insert([
            'department_name' => 'Marketing'
        ]);
        $query->insert([
            'department_name' => 'Operations'
        ]);
        \App\Models\Employee::factory(100)->create();
    }
}
