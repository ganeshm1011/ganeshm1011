<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Employee extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     * 
     */
    public function up()
    {
        Schema::create('TBL_EMPLOYEE',function(Blueprint $table) {
            $table->engine = 'InnoDB'; 
            $table->increments('EMPLOYEE_ID');
            $table->string('EMPLOYEE_NAME',250);
            $table->integer('DEPARTMENT_ID')->references('DEPARTMENT_ID')->on('TBL_DEPARTMENT')->constrained('TBL_DEPARTMENT');
            $table->date('DATE_OF_BIRTH');
            $table->date('DATE_OF_JOIN');
            $table->integer('SALARY');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('TBL_EMPLOYEE');
    }
}
