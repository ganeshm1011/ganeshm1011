<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Department extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('TBL_DEPARTMENT',function(Blueprint $table){
            $table->engine = 'InnoDB';
            $table->increments('DEPARTMENT_ID',11);
            $table->string('DEPARTMENT_NAME',250);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('TBL_DEPARTMENT');
    }
}
