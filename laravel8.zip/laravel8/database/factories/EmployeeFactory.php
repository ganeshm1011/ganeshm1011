<?php

namespace Database\Factories;

use App\Models\Employee;
use Illuminate\Database\Eloquent\Factories\Factory;

class EmployeeFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Employee::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        $dob_start_date = "1980-01-01";
        $dob_end_date = "2000-12-31";
        $doj_start_date = "2000-01-01";
        $doj_end_date = "2020-12-31";
        return [
            'employee_name' => $this->faker->name(),
            'department_id' => rand(1,6),
            'date_of_birth' => $this->faker->dateTimeBetween($dob_start_date,$dob_end_date,$timezone = null),
            'date_of_join' => $this->faker->dateTimeBetween($doj_start_date,$doj_end_date,$timezone = null),
            'salary' => rand(10000,120000),
        ];
    }
}
