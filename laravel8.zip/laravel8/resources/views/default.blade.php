<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Laravel</title>
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet" />
        <!-- Styles -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <link href="//cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css" rel="stylesheet" />
        <style>
            body {
                font-family: 'Nunito', sans-serif;
            }
            body { margin:50px 0px; }
            .dataTable { margin:20px 0px !important;text-align:left; }
            .empBlock {  max-width:80%;margin:auto; }
        </style>
    </head>
    <body>
        <div class="empBlock"> 
            <div class="input-group mb-3">
                <select class="custom-select" id="inputGroupSelect01" onchange="checkDepartment();">
                    <option selected value="">Choose..</option>
                    <option value="AS">Average Salary of Department</option>
                    <option value="HS">Average Highest Salary of Department</option>
                    <option value="HP">Top 15 Highest Paid</option>
                    <option value="BM">Birth of this Month</option>
                    <option value="CE">10 Years Completed Employees</option>
                </select>
                <?php /*<select class="custom-select d-none" id="inputGroupSelect02">
                    <option selected value="">Choose Department</option>
                    @if(isset($department) && count($department) > 0 )
                        @foreach($department as $key => $val)
                            <option value="{{ $val->DEPARTMENT_ID }}">{{ ucwords(strtolower($val->DEPARTMENT_NAME)) }}</option>
                        @endforeach
                    @endif
                </select> */ ?>
                <div class="input-group-append">
                    <button class="btn btn-dark" type="button" onclick="search();">Search</button>
                </div>
            </div>
            <div id="tblContent">
                @include('employee_list')
            </div>
        </div>
        <div class="modal fade" id="loaderModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-body text-center bg-light">
                    <img src="/assets/images/loader.gif" alt="loading" />
                </div>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
        <script src="//cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js" type="text/javascript"></script>
        <script>
            $(document).ready(function (){
                $('#empTable').DataTable({
                    'searching':false,
                    "bLengthChange": false,
                });
            });
            function checkDepartment() {
                $('#inputGroupSelect02 option[value=""]').prop('selected',true);
                var searchVal = $('#inputGroupSelect01').val();
                if(searchVal == "AS" || searchVal == "HS" ) { 
                    $('#inputGroupSelect02').removeClass('d-none');
                }else { 
                    $('#inputGroupSelect02').addClass('d-none');
                }
            }
            function search() {
                var searchVal = $('#inputGroupSelect01').val();
                var dept = $('#inputGroupSelect02').val();
                if(searchVal == "") { alert('Choose anything to Search'); return false; }
                var searchValText = $('#inputGroupSelect01 option:selected').html();
                //if((searchVal == "AS" || searchVal == "HS") && dept=="" ) { alert('Choose Department'); return false; }
                $.ajax({
                    type:"POST",
                    url : "{{ route('search') }}",
                    data:{ "searchVal":searchVal,"searchValText":searchValText,"dept":dept,"_token": "{{ csrf_token() }}" },
                    beforeSend:function(){ showLoader(); },
                    error:function() {
                        alert('something went wrong.');
                    },
                    success:function(result){
                        $("#tblContent").html(result);
                        $('#empTable').DataTable({
                            'searching':false,
                            "bLengthChange": false,
                            "sorting":false
                        });
                        
                    },
                    complete:function(){ hideLoader(); }
                });
            }
            function showLoader() {
                $('#loaderModal').modal('show');
            }
            function hideLoader() {
                $('#loaderModal').modal('hide');
            }

       </script>
        
    </body>
</html>
