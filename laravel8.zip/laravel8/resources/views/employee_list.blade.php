<?php  
$download = $_POST['download'] ?? 'N';
if( $download == "Y" ) { 
$fileName = $searchValText."_".date('d_m_Y').".xls";
 
// Headers for download 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
header("Content-Type: application/vnd.ms-excel"); 
} ?>
<table id="empTable" class="dataTable" border="1">
    @if( $download == "Y" )
    <tr>
        <td style="text-align:center;padding:10px;" colspan="5"><strong>{{ $searchValText }}</strong></td>
    </tr>
    @endif
    <thead>
        <tr>
            <th>Employee Name</th>
            <th>Department</th>
            <th>Date of Birth</th>
            <th>Date of Joining</th>
            <th>Salary(Monthly)</th>
        </tr>
    </thead>
    <tbody>
        @if(isset($empList) && count($empList) > 0 )
            @foreach($empList as $key => $val)
                <tr>
                    <td>{{ $val->EMPLOYEE_NAME }}</td>
                    <td>{{ $val->DEPARTMENT_NAME }}</td>
                    <td>{{ $val->DATE_OF_BIRTH }}</td>
                    <td>{{ $val->DATE_OF_JOIN }}</td>
                    <td style="text-align:right;">{{ $val->SALARY }}</td>
                </tr>
            @endforeach
        @endif
    </tbody>
</table>
@if(isset($empList) && count($empList) > 0 && $download == "N" && $_SERVER['REQUEST_METHOD'] == "POST")
    <form method="post" action="{{ route('search') }}">
        @csrf
        <input type="hidden" class="searchVal" name="searchVal" value="{{ $_POST['searchVal'] ?? '' }}" />
        <input type="hidden" class="dept" name="dept" value="{{ $_POST['dept'] ?? '' }}" />
        <input type="hidden" name="download" value="Y" />
        <input type="hidden" name="searchValText" value="{{ $_POST['searchValText'] }}" />
        <button class="btn btn-dark w-100 mt-2">Download as Excel</button>
    </form>
@endif