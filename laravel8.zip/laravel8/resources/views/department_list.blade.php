<?php  
$download = $_POST['download'] ?? 'N';
if( $download == "Y" ) { 
$fileName = $searchValText."_".date('d_m_Y').".xls";
 
// Headers for download 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
header("Content-Type: application/vnd.ms-excel"); 
} ?>
<table id="empTable" class="dataTable" border="1">
    <thead>
        <tr>
            <th>Department Name</th>
            <th>Average Salary(Monthly)</th>
        </tr>
    </thead>
    <tbody>
        @if(isset($empList) && count($empList) > 0 )
            @foreach($empList as $key => $val)
                <tr>
                    <td>{{ $val->department_name }}</td>
                    <td style="text-align:right;">{{ $val->avg_salary }}</td>
                </tr>
            @endforeach
        @endif
    </tbody>
</table>
@if(isset($empList) && count($empList) > 0 && $download == "N")
    <form method="post" action="{{ route('search') }}">
        @csrf
        <input type="hidden" class="searchVal" name="searchVal" value="{{ $_POST['searchVal'] ?? '' }}" />
        <input type="hidden" class="dept" name="dept" value="{{ $_POST['dept'] ?? '' }}" />
        <input type="hidden" name="download" value="Y" />
        <input type="hidden" name="searchValText" value="{{ $_POST['searchValText'] }}" />
        <button class="btn btn-dark w-100 mt-2">Download as Excel</button>
    </form>
@endif
<?php exit; ?>